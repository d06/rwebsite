library(shiny)
shinyUI(fluidPage(
  titlePanel(title = h4("demostrate the rendomplot on histogram  for iris datasets",align="centr")),
  sidebarLayout(
    sidebarPanel(
      selectInput("var","1.Select the variable",choices = c("Sepal.Length"=1,"Sepal.Width"=2,"Petal.Length"=3,"Petal.Width"= 4)),
    br(),
    sliderInput("bins","2.Select the number of BINs, of the hostogram",min=5,max=25,value=15),
    br(),
    radioButtons("colour","3.Select the colours of histogram",choices = c("green","Red","pink"),selected = "green")
    
        ),
    mainPanel(
      tabsetPanel(type="tab",
                  tabPanel("summary",verbatimTextOutput("summ")),
                  tabPanel("structure",verbatimTextOutput("str")),
                  tabPanel("Data",tableOutput("data")),
                  tabPanel("plot",plotOutput("myhist")))
      
      )
  )
))